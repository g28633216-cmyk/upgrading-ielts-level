# IELTS Boost

Offline-first, o'zbek tilidagi IELTS tayyorlov ilovasi (Expo / React Native): 12 haftalik Reading, Writing, Speaking rejasi, Anki uslubidagi kartalar, taymer, ovoz yozish va natijalar.

## Run & Operate

- `pnpm --filter @workspace/ielts-boost-mobile run dev` — Expo dev server (Expo Go uchun QR)
- `pnpm run typecheck` — barcha paketlar bo'yicha tekshiruv
- APK: `artifacts/ielts-boost-mobile/APK_QOLLANMA.md`

## Where things live

- `artifacts/ielts-boost-mobile/app/(tabs)/` — ekranlar (Bugun, Mashq, Kartalar, Natija, Sozlama)
- `artifacts/ielts-boost-mobile/contexts/AppStore.tsx` — yagona holat, shifrlangan saqlash, taymer, eslatma, zaxira nusxa
- `artifacts/ielts-boost-mobile/data/plan.ts` — 12 haftalik reja va resurs havolalari
- `artifacts/ielts-boost-mobile/data/offline-practice.ts` — offline passage va Writing topshiriqlari
- `artifacts/ielts-boost-design/` — dizayn tokenlari va native primitives

## User preferences

- `data/plan.ts` va `data/offline-practice.ts` ichidagi reja, daqiqalar, darsliklar, resurs havolalari va matnlarni HECH QACHON o'zgartirma, o'chirma, qisqartirma.
- Ilova to'liq offline ishlashi shart. Server, baza va tashqi API qo'shilmasin.
- Asosiy funksiyalar (reja, kartalar, taymer, ovoz yozish, natijalar) olib tashlanmasin.

## Gotchas

- `update()` yuklanish tugaguncha o'zgarishlarni qabul qilmaydi; ekranlar splash orqali kutadi.
- Yangi maydon qo'shsangiz `AppStore.tsx` dagi `normalizeState` va `initialState` ni ham yangilang (eski saqlangan ma'lumot buzilmasligi uchun).
- `artifacts/api-server`, `lib/db`, `mockup-sandbox` mobil ilova uchun kerak emas.
