import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Crypto from "expo-crypto";
import * as Notifications from "expo-notifications";
import * as SecureStore from "expo-secure-store";
import { AppState as NativeAppState, Platform } from "react-native";
import { gcm } from "@noble/ciphers/aes.js";
import { makeSeedCards, type StudyCard } from "../data/flashcards";
import { dateKey } from "../data/plan";

const STATE_KEY = "ielts-boost.enc.v1";
const BACKUP_KEY = "ielts-boost.enc.v1.bak";
const DEVICE_KEY = "ielts-boost.aes-key.v1";
const MAX_NEW_CARDS = 10;

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export type TimerState = {
  label: string;
  endsAt: number | null;
  remainingSeconds: number | null;
  notificationId: string | null;
};

export type DailyReminder = { hour: number; minute: number; notificationId: string | null };
export type ReviewLog = { reviewed: number; correct: number; newCards: number };
export type AppState = {
  planStart: string | null;
  done: Record<string, boolean>;
  doneAt: Record<string, string>;
  writingResponses: Record<string, string>;
  writingScores: Record<string, Record<string, string>>;
  readingMetrics: Record<string, { correct: string; total: string }>;
  readingAnswers: Record<string, number>;
  speakingScores: Record<string, Record<string, string>>;
  audioNotes: Record<string, string>;
  cueCardsDone: Record<string, boolean>;
  cards: StudyCard[];
  reviewLog: Record<string, ReviewLog>;
  notificationsEnabled: boolean;
  timer: TimerState | null;
  dailyReminder: DailyReminder | null;
};

const initialState = (): AppState => ({
  planStart: null,
  done: {},
  doneAt: {},
  writingResponses: {},
  writingScores: {},
  readingMetrics: {},
  readingAnswers: {},
  speakingScores: {},
  audioNotes: {},
  cueCardsDone: {},
  cards: makeSeedCards(),
  reviewLog: {},
  notificationsEnabled: false,
  timer: null,
  dailyReminder: null,
});

const StoreContext = createContext<{
  state: AppState;
  update: (change: (current: AppState) => AppState) => void;
  loading: boolean;
  storageError: string | null;
  notice: string | null;
  dismissNotice: () => void;
  saveFailed: boolean;
  savedAt: number | null;
  toggleTask: (key: string) => void;
  startTimer: (label: string, minutes: number) => Promise<boolean>;
  pauseTimer: () => Promise<void>;
  resumeTimer: () => Promise<boolean>;
  stopTimer: () => Promise<void>;
  requestNotifications: () => Promise<boolean>;
  setDailyReminder: (hour: number, minute: number) => Promise<boolean>;
  clearDailyReminder: () => Promise<void>;
  exportData: () => string;
  importData: (raw: string) => { ok: boolean; message: string };
  resetData: () => Promise<void>;
} | null>(null);

function toBytes(value: string) {
  const encoded = encodeURIComponent(value);
  const result: number[] = [];
  for (let index = 0; index < encoded.length; index += 1) {
    if (encoded[index] === "%") {
      result.push(Number.parseInt(encoded.slice(index + 1, index + 3), 16));
      index += 2;
    } else {
      result.push(encoded.charCodeAt(index));
    }
  }
  return Uint8Array.from(result);
}

function fromBytes(bytes: Uint8Array) {
  return decodeURIComponent(Array.from(bytes, (byte) => `%${byte.toString(16).padStart(2, "0")}`).join(""));
}

function toHex(bytes: Uint8Array) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function fromHex(value: string) {
  if (value.length % 2 !== 0 || !/^[0-9a-f]+$/i.test(value)) throw new Error("Kalit formati noto‘g‘ri.");
  const bytes = new Uint8Array(value.length / 2);
  for (let index = 0; index < bytes.length; index += 1) {
    bytes[index] = Number.parseInt(value.slice(index * 2, index * 2 + 2), 16);
  }
  return bytes;
}

async function secureKey(create: boolean) {
  const current = await SecureStore.getItemAsync(DEVICE_KEY);
  if (current) return fromHex(current);
  if (!create) {
    const missing = new Error("Qurilma kaliti topilmadi.");
    missing.name = "KeyMissing";
    throw missing;
  }
  const key = Crypto.getRandomBytes(32);
  await SecureStore.setItemAsync(DEVICE_KEY, toHex(key), {
    keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
  });
  return key;
}

function mergeSeedCards(cards: StudyCard[] | undefined) {
  const saved = Array.isArray(cards) ? cards : [];
  const known = new Set(saved.map((card) => card.id));
  return [...saved, ...makeSeedCards().filter((card) => !known.has(card.id))];
}

function normalizeState(parsed: Partial<AppState>): AppState {
  return {
    ...initialState(),
    ...parsed,
    cards: mergeSeedCards(parsed.cards),
    done: parsed.done ?? {},
    doneAt: parsed.doneAt ?? {},
    writingResponses: parsed.writingResponses ?? {},
    writingScores: parsed.writingScores ?? {},
    readingMetrics: parsed.readingMetrics ?? {},
    readingAnswers: parsed.readingAnswers ?? {},
    speakingScores: parsed.speakingScores ?? {},
    audioNotes: parsed.audioNotes ?? {},
    cueCardsDone: parsed.cueCardsDone ?? {},
    reviewLog: parsed.reviewLog ?? {},
    dailyReminder: parsed.dailyReminder ?? null,
  };
}

const FRESH_START_NOTICE =
  "Avvalgi saqlangan ma’lumotni ochib bo‘lmadi (qurilma kaliti o‘zgargan yoki fayl buzilgan), shuning uchun yangi boshlandi. Endi Sozlamalar → Zaxira nusxa orqali vaqti-vaqti bilan nusxa oling.";

async function loadEncryptedState(): Promise<{ state: AppState; notice: string | null }> {
  const encrypted = await AsyncStorage.getItem(STATE_KEY);
  if (!encrypted) return { state: initialState(), notice: null };
  const freshStart = async () => {
    await AsyncStorage.setItem(BACKUP_KEY, encrypted).catch(() => undefined);
    return { state: initialState(), notice: FRESH_START_NOTICE };
  };
  let key: Uint8Array;
  try {
    key = await secureKey(false);
  } catch (error) {
    if (error instanceof Error && error.name === "KeyMissing") return freshStart();
    // Vaqtinchalik xato bo‘lishi mumkin (masalan, qulflangan qurilma): bir marta qayta urinamiz.
    await new Promise((resolve) => setTimeout(resolve, 600));
    key = await secureKey(false);
  }
  try {
    const [nonceHex, ciphertextHex] = encrypted.split(".");
    if (!nonceHex || !ciphertextHex) throw new Error("format");
    const plain = gcm(key, fromHex(nonceHex)).decrypt(fromHex(ciphertextHex));
    return { state: normalizeState(JSON.parse(fromBytes(plain)) as Partial<AppState>), notice: null };
  } catch {
    return freshStart();
  }
}

async function saveEncryptedState(state: AppState) {
  const key = await secureKey(true);
  const nonce = Crypto.getRandomBytes(12);
  const ciphertext = gcm(key, nonce).encrypt(toBytes(JSON.stringify(state)));
  await AsyncStorage.setItem(STATE_KEY, `${toHex(nonce)}.${toHex(ciphertext)}`);
}

async function askForNotificationPermission() {
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("study-timers", {
      name: "Study timers",
      importance: Notifications.AndroidImportance.MAX,
      sound: "default",
      vibrationPattern: [0, 250, 250, 250],
    });
  }
  const current = await Notifications.getPermissionsAsync();
  if (current.granted) return true;
  const permission = await Notifications.requestPermissionsAsync();
  return Boolean(permission.granted);
}

async function scheduleTimerNotification(label: string, endsAt: number, allowed: boolean) {
  if (!allowed) return null;
  try {
    return await Notifications.scheduleNotificationAsync({
      content: {
        title: "IELTS Boost · taymer tugadi",
        body: `${label} uchun ajratilgan vaqt tugadi.`,
        sound: "default",
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: new Date(endsAt),
        ...(Platform.OS === "android" ? { channelId: "study-timers" } : {}),
      },
    });
  } catch {
    return null;
  }
}

export function AppStoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(initialState);
  const [loading, setLoading] = useState(true);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saveFailed, setSaveFailed] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const stateRef = useRef(state);
  stateRef.current = state;
  const loadingRef = useRef(true);
  loadingRef.current = loading;
  const blockedRef = useRef(false);
  blockedRef.current = Boolean(storageError);
  const dirtyRef = useRef(false);
  const saveChain = useRef<Promise<void>>(Promise.resolve());

  useEffect(() => {
    let mounted = true;
    loadEncryptedState()
      .then((loaded) => {
        if (!mounted) return;
        setState(loaded.state);
        if (loaded.notice) setNotice(loaded.notice);
      })
      .catch(() => {
        if (mounted) {
          setStorageError(
            "Saqlangan ma’lumotni hozir ochib bo‘lmadi. Eski ma’lumot buzilmaydi, lekin yangi o‘zgarishlar saqlanmaydi. Ilovani to‘liq yopib, qayta oching.",
          );
        }
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const persist = useCallback(() => {
    if (blockedRef.current || loadingRef.current) return saveChain.current;
    const snapshot = stateRef.current;
    dirtyRef.current = false;
    saveChain.current = saveChain.current
      .then(() => saveEncryptedState(snapshot))
      .then(() => {
        setSavedAt(Date.now());
        setSaveFailed(false);
      })
      .catch(() => {
        dirtyRef.current = true;
        setSaveFailed(true);
      });
    return saveChain.current;
  }, []);

  useEffect(() => {
    if (loading) return;
    dirtyRef.current = true;
    const saveTimer = setTimeout(() => void persist(), 500);
    return () => clearTimeout(saveTimer);
  }, [state, loading, persist]);

  // Ilova fonga o‘tganda (masalan, YouTube ochilganda) kutilayotgan o‘zgarishlarni darhol saqlaymiz.
  useEffect(() => {
    const subscription = NativeAppState.addEventListener("change", (next) => {
      if (next !== "active" && dirtyRef.current) void persist();
    });
    return () => subscription.remove();
  }, [persist]);

  const update = useCallback((change: (current: AppState) => AppState) => {
    if (loadingRef.current) return;
    setState((current) => change(current));
  }, []);

  const dismissNotice = useCallback(() => setNotice(null), []);

  const toggleTask = useCallback((key: string) => {
    update((current) => {
      const done = { ...current.done };
      const doneAt = { ...current.doneAt };
      if (done[key]) {
        delete done[key];
        delete doneAt[key];
      } else {
        done[key] = true;
        doneAt[key] = dateKey();
      }
      return { ...current, done, doneAt };
    });
  }, [update]);

  const stopTimer = useCallback(async () => {
    const notificationId = stateRef.current.timer?.notificationId;
    if (notificationId) await Notifications.cancelScheduledNotificationAsync(notificationId).catch(() => undefined);
    update((current) => ({ ...current, timer: null }));
  }, [update]);

  const requestNotifications = useCallback(async () => {
    try {
      const granted = await askForNotificationPermission();
      update((current) => ({ ...current, notificationsEnabled: granted }));
      return granted;
    } catch {
      update((current) => ({ ...current, notificationsEnabled: false }));
      return false;
    }
  }, [update]);

  const startTimer = useCallback(async (label: string, minutes: number) => {
    const priorId = stateRef.current.timer?.notificationId;
    if (priorId) await Notifications.cancelScheduledNotificationAsync(priorId).catch(() => undefined);
    let granted = stateRef.current.notificationsEnabled;
    if (!granted) granted = await requestNotifications();
    const endsAt = Date.now() + Math.max(1, minutes * 60) * 1000;
    const notificationId = await scheduleTimerNotification(label, endsAt, granted);
    update((current) => ({
      ...current,
      notificationsEnabled: granted,
      timer: { label, endsAt, remainingSeconds: null, notificationId },
    }));
    return granted && Boolean(notificationId);
  }, [requestNotifications, update]);

  const pauseTimer = useCallback(async () => {
    const timer = stateRef.current.timer;
    if (!timer?.endsAt) return;
    if (timer.notificationId) await Notifications.cancelScheduledNotificationAsync(timer.notificationId).catch(() => undefined);
    update((current) => ({
      ...current,
      timer: current.timer
        ? { ...current.timer, endsAt: null, remainingSeconds: Math.max(1, Math.ceil((timer.endsAt! - Date.now()) / 1000)), notificationId: null }
        : null,
    }));
  }, [update]);

  const resumeTimer = useCallback(async () => {
    const timer = stateRef.current.timer;
    if (!timer || timer.remainingSeconds == null) return false;
    const granted = timer.notificationId ? true : stateRef.current.notificationsEnabled || await requestNotifications();
    const endsAt = Date.now() + Math.max(1, timer.remainingSeconds) * 1000;
    const notificationId = await scheduleTimerNotification(timer.label, endsAt, granted);
    update((current) => ({
      ...current,
      notificationsEnabled: granted,
      timer: current.timer ? { ...current.timer, endsAt, remainingSeconds: null, notificationId } : null,
    }));
    return granted && Boolean(notificationId);
  }, [requestNotifications, update]);

  const clearDailyReminder = useCallback(async () => {
    const priorId = stateRef.current.dailyReminder?.notificationId;
    if (priorId) await Notifications.cancelScheduledNotificationAsync(priorId).catch(() => undefined);
    update((current) => ({ ...current, dailyReminder: null }));
  }, [update]);

  const setDailyReminder = useCallback(async (hour: number, minute: number) => {
    const priorId = stateRef.current.dailyReminder?.notificationId;
    if (priorId) await Notifications.cancelScheduledNotificationAsync(priorId).catch(() => undefined);
    const granted = stateRef.current.notificationsEnabled || (await requestNotifications());
    if (!granted) {
      update((current) => ({ ...current, dailyReminder: null }));
      return false;
    }
    try {
      const notificationId = await Notifications.scheduleNotificationAsync({
        content: {
          title: "IELTS Boost",
          body: "Bugungi reja kutyapti: Reading, Writing, Speaking va kartalarni takrorlang.",
          sound: "default",
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DAILY,
          hour,
          minute,
          ...(Platform.OS === "android" ? { channelId: "study-timers" } : {}),
        },
      });
      update((current) => ({ ...current, dailyReminder: { hour, minute, notificationId } }));
      return true;
    } catch {
      update((current) => ({ ...current, dailyReminder: null }));
      return false;
    }
  }, [requestNotifications, update]);

  const exportData = useCallback(() => {
    const { timer: _timer, dailyReminder: _reminder, audioNotes: _audio, notificationsEnabled: _notifications, cards, ...portable } = stateRef.current;
    return JSON.stringify({
      app: "ielts-boost",
      version: 1,
      exportedAt: new Date().toISOString(),
      data: {
        ...portable,
        cards: cards.map(({ id, repetitions, ease, intervalDays, dueAt, lapses, lastReviewedAt }) => ({
          id, repetitions, ease, intervalDays, dueAt, lapses, lastReviewedAt,
        })),
      },
    });
  }, []);

  const importData = useCallback((raw: string) => {
    try {
      const parsed = JSON.parse(raw) as { app?: unknown; data?: unknown };
      if (!parsed || parsed.app !== "ielts-boost" || typeof parsed.data !== "object" || parsed.data === null) {
        return { ok: false, message: "Bu IELTS Boost zaxira nusxasi emas. Matnni to‘liq nusxalab qo‘ying." };
      }
      const data = parsed.data as Partial<AppState>;
      const saved = new Map<string, Partial<StudyCard>>();
      for (const item of Array.isArray(data.cards) ? (data.cards as Partial<StudyCard>[]) : []) {
        if (item && typeof item.id === "string") saved.set(item.id, item);
      }
      const num = (value: unknown, fallback: number) => (typeof value === "number" && Number.isFinite(value) ? value : fallback);
      const cards = makeSeedCards().map((seed) => {
        const item = saved.get(seed.id);
        if (!item) return seed;
        return {
          ...seed,
          repetitions: num(item.repetitions, seed.repetitions),
          ease: num(item.ease, seed.ease),
          intervalDays: num(item.intervalDays, seed.intervalDays),
          lapses: num(item.lapses, seed.lapses),
          dueAt: typeof item.dueAt === "string" && /^\d{4}-\d{2}-\d{2}$/.test(item.dueAt) ? item.dueAt : seed.dueAt,
          lastReviewedAt: typeof item.lastReviewedAt === "string" ? item.lastReviewedAt : undefined,
        };
      });
      const restored = normalizeState({ ...data, cards });
      setState((current) => ({
        ...restored,
        timer: current.timer,
        dailyReminder: current.dailyReminder,
        audioNotes: current.audioNotes,
        notificationsEnabled: current.notificationsEnabled,
      }));
      return { ok: true, message: "Ma’lumotlar muvaffaqiyatli tiklandi." };
    } catch {
      return { ok: false, message: "Matnni o‘qib bo‘lmadi. Zaxira nusxani to‘liq va o‘zgartirmasdan qo‘ying." };
    }
  }, []);

  const resetData = useCallback(async () => {
    const { timer, dailyReminder } = stateRef.current;
    if (timer?.notificationId) await Notifications.cancelScheduledNotificationAsync(timer.notificationId).catch(() => undefined);
    if (dailyReminder?.notificationId) await Notifications.cancelScheduledNotificationAsync(dailyReminder.notificationId).catch(() => undefined);
    await AsyncStorage.removeItem(STATE_KEY);
    await AsyncStorage.removeItem(BACKUP_KEY).catch(() => undefined);
    await SecureStore.deleteItemAsync(DEVICE_KEY);
    setStorageError(null);
    setNotice(null);
    setSaveFailed(false);
    setState(initialState());
    setSavedAt(null);
  }, []);

  const value = useMemo(() => ({
    state, update, loading, storageError, notice, dismissNotice, saveFailed, savedAt, toggleTask,
    startTimer, pauseTimer, resumeTimer, stopTimer, requestNotifications,
    setDailyReminder, clearDailyReminder, exportData, importData, resetData,
  }), [state, update, loading, storageError, notice, dismissNotice, saveFailed, savedAt, toggleTask, startTimer, pauseTimer, resumeTimer, stopTimer, requestNotifications, setDailyReminder, clearDailyReminder, exportData, importData, resetData]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

/** Sekundiga bir marta yangilanadigan vaqt. Faqat kerak bo‘lgan komponentda ishlatiladi (butun ilova qayta chizilmaydi). */
export function useNow(active = true) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!active) return;
    setNow(Date.now());
    const ticker = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(ticker);
  }, [active]);
  return now;
}

export function useAppStore() {
  const store = useContext(StoreContext);
  if (!store) throw new Error("useAppStore must be used inside AppStoreProvider");
  return store;
}

export const NEW_CARD_LIMIT = MAX_NEW_CARDS;
