# Ilovani telefonga o'rnatish

## 1. Tezkor sinov (Expo Go)
Replit'da loyihani ishga tushiring va QR-kodni Expo Go bilan skanerlang. Internet kerak bo'ladi.

## 2. APK yaratish (o'rnatib, internetsiz ishlatish)
Bu bosqich kompyuterda yoki Replit Shell'da bajariladi. Expo akkaunti kerak (bepul: expo.dev).

```
cd artifacts/ielts-boost-mobile
npx eas-cli login
npx eas-cli build -p android --profile preview
```

Build tugagach (taxminan 10–20 daqiqa) havola chiqadi. Uni telefonda ochib, `.apk` faylni yuklab oling va o'rnating (Android "noma'lum manbadan o'rnatish"ni so'raydi).

Paket nomi: `com.ieltsboost.mobile`. Google Play uchun nashr qilmoqchi bo'lsangiz, uni birinchi build'dan oldin `app.json` da o'zgartiring.

## 3. Ma'lumotni saqlash
Sozlamalar → "Zaxira nusxa yaratish" tugmasi bilan natijalaringizni matn qilib saqlab qo'ying. Telefon almashganda "Zaxiradan tiklash" orqali qaytaring.
