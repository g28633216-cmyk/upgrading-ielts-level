import React, { useState } from "react";
import { Alert, View } from "react-native";
import { AudioModule, RecordingPresets, setAudioModeAsync, useAudioPlayer, useAudioRecorder } from "expo-audio";
import * as FileSystem from "expo-file-system/legacy";
import { NativeButton, NativeCard, NativeText } from "@workspace/ielts-boost-design/native/primitives";
import { useAppStore } from "../contexts/AppStore";

export function AudioRecorderCard({ sessionKey }: { sessionKey: string }) {
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const { state, update } = useAppStore();
  const savedUri = state.audioNotes[sessionKey] ?? null;
  // iOS’da hujjatlar papkasi yo‘li yangilanishda o‘zgaradi, shuning uchun faqat fayl nomidan foydalanamiz.
  const playableUri = savedUri && FileSystem.documentDirectory
    ? `${FileSystem.documentDirectory}${savedUri.split("/").pop()}`
    : savedUri;
  const player = useAudioPlayer(playableUri);
  const [recording, setRecording] = useState(false);
  const [busy, setBusy] = useState(false);

  const begin = async () => {
    setBusy(true);
    try {
      const permission = await AudioModule.requestRecordingPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("Mikrofon ruxsati kerak", "Ovozingizni yozish uchun mikrofon ruxsatini telefon sozlamalaridan yoqing.");
        return;
      }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
      setRecording(true);
    } catch {
      Alert.alert("Yozishni boshlay olmadik", "Mikrofon ruxsati va qurilma sozlamalarini tekshiring.");
    } finally {
      setBusy(false);
    }
  };

  const finish = async () => {
    setBusy(true);
    try {
      await recorder.stop();
      setRecording(false);
      const uri = recorder.uri;
      if (!uri || !FileSystem.documentDirectory) throw new Error("Ovoz fayli topilmadi.");
      const destination = `${FileSystem.documentDirectory}speaking-${Date.now()}.m4a`;
      await FileSystem.copyAsync({ from: uri, to: destination });
      update((current) => ({ ...current, audioNotes: { ...current.audioNotes, [sessionKey]: destination } }));
      // Eski yozuv telefon xotirasini egallab qolmasin.
      if (playableUri) await FileSystem.deleteAsync(playableUri, { idempotent: true }).catch(() => undefined);
      await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
    } catch {
      Alert.alert("Yozuv saqlanmadi", "Yozuvni qaytadan yozib ko‘ring.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <NativeCard style={{ gap: 10 }}>
      <NativeText variant="title">Ovozingizni yozib, qayta tinglang</NativeText>
      <NativeText variant="caption" tone="muted">Yozuv faqat shu telefonda saqlanadi. Ilova uni hech qayerga yubormaydi.</NativeText>
      <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
        {recording ? (
          <NativeButton variant="danger" onPress={() => void finish()} disabled={busy}>■ Yozishni to‘xtatish</NativeButton>
        ) : (
          <NativeButton onPress={() => void begin()} disabled={busy}>● Yozishni boshlash</NativeButton>
        )}
        {savedUri && !recording ? (
          <NativeButton variant="secondary" onPress={() => { void player.seekTo(0).then(() => player.play()).catch(() => player.play()); }}>▶ Oxirgi yozuv</NativeButton>
        ) : null}
      </View>
    </NativeCard>
  );
}
