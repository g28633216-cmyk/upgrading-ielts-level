import React, { useEffect, useRef } from "react";
import { View } from "react-native";
import { NativeBadge, NativeButton, NativeCard, NativeText } from "@workspace/ielts-boost-design/native/primitives";
import { useColors } from "@workspace/ielts-boost-design/hooks/use-colors";
import * as Haptics from "expo-haptics";
import { useAppStore, useNow } from "../contexts/AppStore";

export function TimerBanner() {
  const { state, pauseTimer, resumeTimer, stopTimer } = useAppStore();
  const { colors } = useColors();
  const timer = state.timer;
  const now = useNow(Boolean(timer?.endsAt));
  const seconds = !timer
    ? 0
    : timer.endsAt
      ? Math.max(0, Math.ceil((timer.endsAt - now) / 1000))
      : Math.max(0, timer.remainingSeconds ?? 0);
  const finished = Boolean(timer) && seconds === 0;
  const buzzed = useRef(false);
  useEffect(() => {
    if (finished && !buzzed.current) {
      buzzed.current = true;
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
    }
    if (!finished) buzzed.current = false;
  }, [finished]);
  if (!timer) return null;
  return (
    <NativeCard style={{ gap: 10, marginBottom: 14, borderColor: finished ? colors.destructive : undefined }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
        <View style={{ flex: 1 }}>
          <NativeText variant="label">{finished ? "Vaqt tugadi" : timer.label}</NativeText>
          <NativeText variant="display" style={{ fontSize: 28, lineHeight: 36 }}>
            {String(Math.floor(seconds / 60)).padStart(2, "0")}:{String(seconds % 60).padStart(2, "0")}
          </NativeText>
        </View>
        <NativeBadge tone={finished ? "warning" : "success"}>
          {finished ? "Yakunlandi" : timer.endsAt ? "Ishlayapti" : "Pauza"}
        </NativeBadge>
      </View>
      <View style={{ flexDirection: "row", gap: 8 }}>
        {timer.endsAt && !finished ? (
          <NativeButton variant="secondary" onPress={() => void pauseTimer()} style={{ flex: 1 }}>Pauza</NativeButton>
        ) : (
          <NativeButton onPress={() => void resumeTimer()} style={{ flex: 1 }} disabled={finished}>Davom etish</NativeButton>
        )}
        <NativeButton variant="outline" onPress={() => void stopTimer()} style={{ flex: 1 }}>Yopish</NativeButton>
      </View>
      {!timer.notificationId && !finished ? (
        <NativeText variant="caption" tone="muted">Fon rejimidagi ovozli eslatma uchun bildirishnomalarga ruxsat bering.</NativeText>
      ) : null}
    </NativeCard>
  );
}
