import { READING_PAIRS, SPEAKING_TOPICS } from "./plan";

export type StudyCard = {
  id: string;
  front: string;
  back: string;
  translation: string;
  topic: string;
  repetitions: number;
  ease: number;
  intervalDays: number;
  dueAt: string;
  lapses: number;
  lastReviewedAt?: string;
};

export function makeSeedCards(): StudyCard[] {
  const reading = READING_PAIRS.map((pair, index) => ({
    id: `reading-paraphrase-${index}`,
    front: pair.a,
    back: pair.b,
    translation: `${pair.aUz} · ${pair.bUz}`,
    topic: `Reading · ${pair.type}`,
    repetitions: 0,
    ease: 2.5,
    intervalDays: 0,
    dueAt: "1970-01-01",
    lapses: 0,
  }));
  const speaking = SPEAKING_TOPICS.flatMap((topic, topicIndex) =>
    topic.chunks.map((chunk, chunkIndex) => ({
      id: `speaking-${topicIndex}-${chunkIndex}`,
      front: chunk.phrase,
      back: chunk.uz,
      translation: chunk.uz,
      topic: `Speaking · ${topic.name}`,
      repetitions: 0,
      ease: 2.5,
      intervalDays: 0,
      dueAt: "1970-01-01",
      lapses: 0,
    })),
  );
  return [...reading, ...speaking];
}

/** Bugun ko‘rilishi kerak kartalar soni (Takrorlash ekrani bilan bir xil qoida: muddati kelganlar + kunlik yangi karta limiti). */
export function reviewCounts(cards: StudyCard[], today: string, newToday: number, newLimit: number) {
  let due = 0;
  let fresh = 0;
  for (const card of cards) {
    if (card.dueAt > today) continue;
    if (card.lastReviewedAt) due += 1;
    else fresh += 1;
  }
  return due + Math.min(fresh, Math.max(0, newLimit - newToday));
}

export function shuffle<T>(values: T[]) {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

export function gradeCard(card: StudyCard, grade: 1 | 3 | 4 | 5, today: string): StudyCard {
  const quality = grade;
  let ease = card.ease + 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02);
  ease = Math.max(1.3, ease);
  const repetitions = quality < 3 ? 0 : card.repetitions + 1;
  const intervalDays =
    quality < 3
      ? 1
      : card.repetitions === 0
        ? 1
        : card.repetitions === 1
          ? 6
          : Math.max(1, Math.round(card.intervalDays * ease));
  const [year, month, day] = today.split("-").map(Number);
  const due = new Date(year, month - 1, day + intervalDays);
  const dueAt = `${due.getFullYear()}-${String(due.getMonth() + 1).padStart(2, "0")}-${String(due.getDate()).padStart(2, "0")}`;
  return {
    ...card,
    repetitions,
    ease,
    intervalDays,
    dueAt,
    lapses: card.lapses + (quality < 3 ? 1 : 0),
    lastReviewedAt: today,
  };
}
