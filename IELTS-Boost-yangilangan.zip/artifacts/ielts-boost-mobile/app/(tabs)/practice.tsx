import React, { useEffect, useMemo, useRef, useState } from "react";
import { Alert, Linking, Share, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import {
  NativeBadge,
  NativeButton,
  NativeCard,
  NativeInput,
  NativeProgress,
  NativeText,
} from "@workspace/ielts-boost-design/native/primitives";
import { useColors } from "@workspace/ielts-boost-design/hooks/use-colors";
import { AudioRecorderCard } from "../../components/AudioRecorderCard";
import { ResourceLinks } from "../../components/ResourceLinks";
import { Screen } from "../../components/Screen";
import { TimerBanner } from "../../components/TimerBanner";
import { useAppStore } from "../../contexts/AppStore";
import {
  READING_PAIRS,
  READING_RESOURCES,
  SPEAKING_RESOURCES,
  WEEKDAYS,
  WRITING_RESOURCES,
  addDays,
  dateKey,
  planIndex,
  readingPlan,
  speakingDayMaterial,
  speakingPlan,
  speakingWeekDay,
  weekDayFromIndex,
  writingPhase,
  writingPlan,
} from "../../data/plan";
import { dailyReadingPractice, offlineWritingPrompts } from "../../data/offline-practice";
import type { Skill, StudyTask } from "../../data/plan";

const skills: { id: Skill; label: string; icon: string }[] = [
  { id: "reading", label: "Reading", icon: "◫" },
  { id: "writing", label: "Writing", icon: "✎" },
  { id: "speaking", label: "Speaking", icon: "◉" },
];

function TaskCard({ task, taskKey }: { task: StudyTask; taskKey: string }) {
  const { state, toggleTask, startTimer } = useAppStore();
  const done = Boolean(state.done[taskKey]);
  return (
    <NativeCard style={{ gap: 9 }}>
      <View style={{ flexDirection: "row", gap: 10, alignItems: "flex-start" }}>
        <View style={{ flex: 1, gap: 4 }}>
          <NativeText variant="title" style={{ fontSize: 16 }}>{task.title}</NativeText>
          <NativeText variant="caption" tone="muted">{task.minutes} daqiqa · {task.detail}</NativeText>
        </View>
        <NativeBadge tone={done ? "success" : "muted"}>{done ? "Tayyor" : `${task.minutes} daq`}</NativeBadge>
      </View>
      <View style={{ flexDirection: "row", gap: 8 }}>
        <NativeButton onPress={() => void startTimer(task.title, task.minutes)} style={{ flex: 1 }}>
          ▶ Taymer
        </NativeButton>
        <NativeButton variant={done ? "secondary" : "outline"} onPress={() => toggleTask(taskKey)} style={{ flex: 1 }}>
          {done ? "✓ Bajarildi" : "Belgilash"}
        </NativeButton>
      </View>
    </NativeCard>
  );
}

function OfflinePassageCard({ dayIndex }: { dayIndex: number }) {
  const { state, update } = useAppStore();
  const practice = dailyReadingPractice(dayIndex);
  const key = `offline-passage-${dayIndex}`;
  const picked = state.readingAnswers[key];
  const { question } = practice;
  return (
    <NativeCard style={{ gap: 9 }}>
      <NativeBadge tone="success">Offline · Hafta {practice.week}, kun {practice.day} · savol {practice.questionNumber}/3</NativeBadge>
      <NativeText variant="title">{practice.title}</NativeText>
      <NativeText>{practice.passage}</NativeText>
      <NativeText variant="label">{question.prompt}</NativeText>
      {question.choices.map((choice, index) => (
        <NativeButton
          key={choice}
          variant={picked === index ? (index === question.answer ? "primary" : "danger") : "outline"}
          onPress={() => update((current) => ({
            ...current,
            readingAnswers: { ...current.readingAnswers, [key]: index },
          }))}
          style={{ alignItems: "flex-start" }}
        >
          {String.fromCharCode(65 + index)}. {choice}
        </NativeButton>
      ))}
      {picked !== undefined ? (
        <NativeText tone={picked === question.answer ? "success" : "warning"}>
          {picked === question.answer ? "To‘g‘ri." : `Javob: ${question.choices[question.answer]}.`} {question.explanation}
        </NativeText>
      ) : null}
      <NativeText variant="caption" tone="muted">
        IELTS Boost’da yozilgan original mashq; Cambridge yoki rasmiy imtihon matni emas. Internet talab qilmaydi.
      </NativeText>
    </NativeCard>
  );
}

function ReadingDrill({ dayIndex }: { dayIndex: number }) {
  const { state, update } = useAppStore();
  const pairIndex = dayIndex % READING_PAIRS.length;
  const pair = READING_PAIRS[pairIndex];
  const alternatives = READING_PAIRS.filter((_, index) => index !== pairIndex)
    .slice(0, 3)
    .map((item) => item.b);
  const options = [pair.b, ...alternatives];
  const rotation = dayIndex % options.length;
  const choices = [...options.slice(rotation), ...options.slice(0, rotation)];
  const answerIndex = (choices.length - rotation) % choices.length;
  const key = `reading-drill-${dayIndex}`;
  const picked = state.readingAnswers[key];
  const metrics = state.readingMetrics[key] ?? { correct: "", total: "" };

  return (
    <NativeCard style={{ gap: 10 }}>
      <NativeBadge tone="accent">{pair.questionType} · tezkor offline mashq</NativeBadge>
      <NativeText variant="title">Mazmuni bir xil bo‘lgan paraphrase’ni tanlang</NativeText>
      <NativeText variant="display" style={{ fontSize: 22, lineHeight: 30 }}>{pair.a}</NativeText>
      {choices.map((choice, index) => (
        <NativeButton
          key={choice}
          variant={picked === index ? (index === answerIndex ? "primary" : "danger") : "outline"}
          onPress={() => update((current) => ({
            ...current,
            readingAnswers: { ...current.readingAnswers, [key]: index },
          }))}
          style={{ alignItems: "flex-start" }}
        >
          {String.fromCharCode(65 + index)}. {choice}
        </NativeButton>
      ))}
      {picked !== undefined ? (
        <NativeText tone={picked === answerIndex ? "success" : "warning"}>
          {picked === answerIndex ? "To‘g‘ri." : "Yana urinib ko‘ring."} {pair.type}: “{pair.a}” va “{pair.b}” bir fikrni turlicha ifodalaydi.
        </NativeText>
      ) : null}
      <View style={{ gap: 7 }}>
        <NativeText variant="label">Bugungi passage natijasi</NativeText>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <NativeInput
            value={metrics.correct}
            keyboardType="number-pad"
            placeholder="To‘g‘ri"
            accessibilityLabel="Reading to‘g‘ri javoblar soni"
            onChangeText={(value) => update((current) => ({
              ...current,
              readingMetrics: { ...current.readingMetrics, [key]: { ...metrics, correct: value } },
            }))}
            style={{ flex: 1 }}
          />
          <NativeInput
            value={metrics.total}
            keyboardType="number-pad"
            placeholder="Jami savol"
            accessibilityLabel="Reading jami savollar soni"
            onChangeText={(value) => update((current) => ({
              ...current,
              readingMetrics: { ...current.readingMetrics, [key]: { ...metrics, total: value } },
            }))}
            style={{ flex: 1 }}
          />
        </View>
      </View>
      <NativeText variant="caption" tone="muted">
        Bu qisqa mashq Cambridge passage o‘rnini bosmaydi. To‘liq Reading testi uchun rasmiy namuna manbalaridan foydalaning.
      </NativeText>
    </NativeCard>
  );
}

function WritingWorkbench({ week, day, sequenceKey }: { week: number; day: number; sequenceKey: string }) {
  const { state, update } = useAppStore();
  const draft = state.writingResponses[sequenceKey] ?? "";
  const scores = state.writingScores[sequenceKey] ?? {};
  const [draftText, setDraftText] = useState(draft);
  const phase = writingPhase(week);
  const row = writingPlan(week, day);
  const offlinePrompts = offlineWritingPrompts(week);

  const latestText = useRef(draftText);
  latestText.current = draftText;
  // Kun almashganda yoki ekrandan chiqilganda yozilgan matn yo‘qolmasligi uchun darhol saqlaymiz.
  useEffect(() => {
    setDraftText(state.writingResponses[sequenceKey] ?? "");
    return () => {
      const text = latestText.current;
      update((current) => (
        (current.writingResponses[sequenceKey] ?? "") === text
          ? current
          : { ...current, writingResponses: { ...current.writingResponses, [sequenceKey]: text } }
      ));
    };
  }, [sequenceKey, update]);
  useEffect(() => {
    if (draftText === draft) return;
    const timeout = setTimeout(() => {
      update((current) => ({
        ...current,
        writingResponses: { ...current.writingResponses, [sequenceKey]: draftText },
      }));
    }, 650);
    return () => clearTimeout(timeout);
  }, [draftText, draft, sequenceKey, update]);

  const shareFeedbackPrompt = () => {
    const prompt = `Act as an IELTS Writing coach. Assess my response using the official IELTS Writing Band Descriptors. Give evidence-based estimates for Task Achievement/Response, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy. Do not rewrite my essay. Identify the three highest-impact improvements and one short exercise for each. Here is my response:\n\n${draftText}`;
    void Share.share({ message: prompt });
  };

  return (
    <View style={{ gap: 12 }}>
      <NativeCard style={{ gap: 8 }}>
        <NativeBadge tone="accent">{phase.title}</NativeBadge>
        <NativeText variant="title">{phase.focus}</NativeText>
        <NativeText tone="muted">Nishon: {phase.target}. 12 haftalik topshiriqlar va daqiqalar saqlandi.</NativeText>
        <NativeText variant="label">Task 1: {`hafta ${week}`} · Task 2: {`hafta ${week}`}</NativeText>
        {row.slice(0, 2).map((task) => (
          <NativeText key={task.id} variant="caption" tone="muted">• {task.title} — {task.minutes} daq</NativeText>
        ))}
      </NativeCard>
      <NativeCard style={{ gap: 8 }}>
        <NativeBadge tone="success">Offline · IELTS Boost original prompts</NativeBadge>
        <NativeText variant="label">Task 1 · haftaning grafik yoki jarayon topshirig‘i</NativeText>
        <NativeText>{offlinePrompts.task1}</NativeText>
        <NativeText variant="label">Task 2 · haftaning essay savoli</NativeText>
        <NativeText>{offlinePrompts.task2}</NativeText>
        <NativeText variant="caption" tone="muted">Bu mashqlar offline ishlaydi; savollar va Task 1 ma’lumotlari IELTS Boost uchun tuzilgan, rasmiy test emas.</NativeText>
      </NativeCard>
      <NativeCard style={{ gap: 9 }}>
        <NativeText variant="title">Yozuv daftari</NativeText>
        <NativeText variant="caption" tone="muted">Javob rejangiz va essengiz avtomatik, shifrlangan holda saqlanadi.</NativeText>
        <NativeInput
          multiline
          maxLength={12000}
          value={draftText}
          onChangeText={setDraftText}
          placeholder="Bugungi reja, Task 1 yoki Task 2 javobingizni yozing…"
          accessibilityLabel="IELTS Writing javobingiz"
        />
        <NativeText variant="caption" tone="muted">{draftText.trim().split(/\s+/).filter(Boolean).length} so‘z · {draftText.length}/12000 belgi</NativeText>
        <NativeButton variant="secondary" onPress={shareFeedbackPrompt} disabled={!draftText.trim()}>
          Tekshiruv promptini ulash
        </NativeButton>
      </NativeCard>
      <NativeCard style={{ gap: 9 }}>
        <NativeText variant="title">O‘z-o‘zingizni baholang</NativeText>
        <NativeText variant="caption" tone="muted">Rasmiy rubrikaga qarab har bir mezonga 0–9 oralig‘ida band kiriting.</NativeText>
        {[
          ["task", "Task Achievement / Response"],
          ["coherence", "Coherence & Cohesion"],
          ["lexical", "Lexical Resource"],
          ["grammar", "Grammatical Range & Accuracy"],
        ].map(([key, label]) => (
          <View key={key} style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
            <NativeText style={{ flex: 1 }}>{label}</NativeText>
            <NativeInput
              keyboardType="decimal-pad"
              placeholder="—"
              value={scores[key] ?? ""}
              onChangeText={(value) => update((current) => ({
                ...current,
                writingScores: {
                  ...current.writingScores,
                  [sequenceKey]: { ...(current.writingScores[sequenceKey] ?? {}), [key]: value },
                },
              }))}
              style={{ width: 72, textAlign: "center" }}
            />
          </View>
        ))}
      </NativeCard>
      <ResourceLinks title="Ishonchli Writing manbalari" resources={WRITING_RESOURCES} />
    </View>
  );
}

function SpeakingWorkbench({ week, day, sequenceKey }: { week: number; day: number; sequenceKey: string }) {
  const { state, update, startTimer } = useAppStore();
  const { colors } = useColors();
  const material = speakingDayMaterial(week, day);
  const tasks = speakingPlan(week, day);
  const cueKey = `${week}:${day}`;
  const cueDone = Boolean(state.cueCardsDone[cueKey]);
  const scores = state.speakingScores[sequenceKey] ?? {};
  const visibleTopics = day === 5
    ? material.topics
    : [material.topics[day === 3 || day === 4 ? 1 : 0]];
  const video = material.video;
  return (
    <View style={{ gap: 12 }}>
      <NativeCard style={{ gap: 9 }}>
        <NativeBadge tone="accent">Bugungi Shadowing · {video.source}</NativeBadge>
        <NativeText variant="title">{video.title}</NativeText>
        <NativeText tone="muted">{video.detail}</NativeText>
        <NativeButton onPress={() => void Linking.openURL(video.url)}>▶ YouTube’da ochish</NativeButton>
        <NativeText variant="caption" tone="muted">Video tashqi YouTube ilovasi yoki brauzerda ochiladi; uni ko‘rish uchun internet kerak.</NativeText>
      </NativeCard>
      {material.cueCard ? (
        <NativeCard style={{ gap: 9 }}>
          <NativeBadge>Cue card · 1 daqiqa reja + 2 daqiqa javob</NativeBadge>
          <NativeText variant="title">{material.cueCard}</NativeText>
          <NativeText tone="muted">You should say: what or who it is · when and where · what happened · and explain why it matters.</NativeText>
          <NativeButton variant="outline" onPress={() => void startTimer("Cue card · 2 daqiqa", 2)}>
            2 daqiqalik javob taymeri
          </NativeButton>
          <NativeButton
            variant={cueDone ? "secondary" : "outline"}
            onPress={() => update((current) => ({
              ...current,
              cueCardsDone: { ...current.cueCardsDone, [cueKey]: !current.cueCardsDone[cueKey] },
            }))}
          >
            {cueDone ? "✓ Gapirildi" : "Gapirdim deb belgilash"}
          </NativeButton>
        </NativeCard>
      ) : null}
      {material.questions.length ? (
        <NativeCard style={{ gap: 8 }}>
          <NativeText variant="title">Bugungi mock savollari</NativeText>
          {material.questions.map((question) => <NativeText key={question}>• {question}</NativeText>)}
          {day === 6 ? <NativeText tone="muted">Part 1 → Part 2 → Part 3 ketma-ketligida, to‘xtamasdan javob bering.</NativeText> : null}
        </NativeCard>
      ) : null}
      {day === 6 ? (
        <NativeCard style={{ gap: 9 }}>
          <NativeBadge tone="success">Full mock · o‘z baholashingiz</NativeBadge>
          <NativeText variant="caption" tone="muted">Javobni yozib oling; so‘ng rasmiy mezonlarga qarab har bir bandni kiriting.</NativeText>
          {[
            ["fluency", "Fluency & Coherence"],
            ["lexical", "Lexical Resource"],
            ["grammar", "Grammar"],
            ["pronunciation", "Pronunciation"],
          ].map(([key, label]) => (
            <View key={key} style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
              <NativeText style={{ flex: 1 }}>{label}</NativeText>
              <NativeInput
                keyboardType="decimal-pad"
                placeholder="—"
                value={scores[key] ?? ""}
                onChangeText={(value) => update((current) => ({
                  ...current,
                  speakingScores: {
                    ...current.speakingScores,
                    [sequenceKey]: { ...(current.speakingScores[sequenceKey] ?? {}), [key]: value },
                  },
                }))}
                style={{ width: 72, textAlign: "center" }}
              />
            </View>
          ))}
        </NativeCard>
      ) : null}
      {visibleTopics.map((topic) => (
        <NativeCard key={topic.name} style={{ gap: 8 }}>
          <NativeText variant="title">{topic.name} · tarjima qilingan chunks</NativeText>
          {topic.chunks.map((chunk) => (
            <View key={chunk.phrase} style={{ paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: colors.border }}>
              <NativeText variant="label">{chunk.phrase}</NativeText>
              <NativeText variant="caption" tone="muted">{chunk.uz}</NativeText>
            </View>
          ))}
          <NativeText variant="caption" tone="muted">Part 1: {topic.part1.join(" · ")}</NativeText>
          <NativeText variant="caption" tone="muted">Part 3: {topic.part3}</NativeText>
        </NativeCard>
      ))}
      {tasks.map((task) => <TaskCard key={task.id} task={task} taskKey={`speaking:${week}:${day}:${task.id}`} />)}
      <AudioRecorderCard sessionKey={sequenceKey} />
      <ResourceLinks title="Speaking baholash va format" resources={SPEAKING_RESOURCES} />
    </View>
  );
}

export default function PracticeScreen() {
  const params = useLocalSearchParams<{ skill?: string }>();
  const { colors } = useColors();
  const { state, loading, storageError } = useAppStore();
  const [skill, setSkill] = useState<Skill>("reading");
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const start = state.planStart;
  const todayIndex = planIndex(start);
  const dayIndex = selectedIndex ?? todayIndex;
  const selectedDate = start ? addDays(start, dayIndex) : dateKey();

  useEffect(() => {
    if (params.skill === "reading" || params.skill === "writing" || params.skill === "speaking") setSkill(params.skill);
  }, [params.skill]);
  useEffect(() => setSelectedIndex(null), [start]);

  const readingSlot = weekDayFromIndex(dayIndex);
  const writingSlot = weekDayFromIndex(Math.min(dayIndex, 83));
  const speakingSlot = speakingWeekDay(start, selectedDate);
  const week = skill === "reading" ? readingSlot.week : skill === "writing" ? writingSlot.week : speakingSlot.week;
  const day = skill === "reading" ? readingSlot.day : skill === "writing" ? writingSlot.day : speakingSlot.day;
  const taskList = useMemo(() => (
    skill === "reading" ? readingPlan(week, day) : skill === "writing" ? writingPlan(week, day) : speakingPlan(week, day)
  ), [skill, week, day]);
  const doneKey = (task: StudyTask) => `${skill}:${week}:${day}:${task.id}`;
  const doneCount = taskList.filter((task) => state.done[doneKey(task)]).length;
  const writingKey = `writing:${week}:${day}`;
  const speakingKey = `speaking:${week}:${day}`;

  if (loading) return <Screen><NativeText variant="title">Ma’lumotlar ochilyapti…</NativeText></Screen>;
  return (
    <Screen>
      <NativeText variant="display">Mashg‘ulot</NativeText>
      <NativeText tone="muted">Original rejaning kunlik bloki, resurslari va natijalari.</NativeText>
      {storageError ? <NativeCard><NativeText tone="warning">{storageError}</NativeText></NativeCard> : null}
      <TimerBanner />
      <View style={{ flexDirection: "row", gap: 7 }}>
        {skills.map((item) => (
          <NativeButton
            key={item.id}
            variant={skill === item.id ? "primary" : "outline"}
            onPress={() => setSkill(item.id)}
            style={{ flex: 1, paddingHorizontal: 5 }}
          >
            {item.icon} {item.label}
          </NativeButton>
        ))}
      </View>
      <NativeCard style={{ gap: 10 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <NativeButton variant="outline" onPress={() => setSelectedIndex(Math.max(0, dayIndex - 1))} disabled={dayIndex === 0}>‹</NativeButton>
          <View style={{ alignItems: "center", flex: 1 }}>
            <NativeText variant="title">Hafta {week} · {WEEKDAYS[day]}</NativeText>
            <NativeText variant="caption" tone="muted">{selectedDate}</NativeText>
          </View>
          <NativeButton variant="outline" onPress={() => setSelectedIndex(dayIndex + 1)}>›</NativeButton>
        </View>
        {!start ? (
          <NativeButton onPress={() => Alert.alert("Avval reja boshlansin", "Bugun sahifasiga qaytib, rejani boshlash tugmasini bosing.")}>
            Rejani boshlash kerak
          </NativeButton>
        ) : null}
        <NativeProgress value={(doneCount / Math.max(1, taskList.length)) * 100} label="Bugungi bloklar" />
        <NativeText variant="caption" tone="muted">{doneCount}/{taskList.length} blok bajarildi · Reading va Writing rejasidagi daqiqalar o‘zgartirilmagan.</NativeText>
      </NativeCard>

      {skill === "reading" ? (
        <>
          <NativeText variant="title">Reading · 12 haftalik reja</NativeText>
          {taskList.map((task) => <TaskCard key={task.id} task={task} taskKey={doneKey(task)} />)}
          <OfflinePassageCard dayIndex={dayIndex} />
          <ReadingDrill dayIndex={dayIndex} />
          <ResourceLinks title="Reading passage va testlar" resources={READING_RESOURCES} />
        </>
      ) : null}

      {skill === "writing" ? (
        <>
          <NativeText variant="title">Writing · 12 haftalik reja</NativeText>
          {taskList.map((task) => <TaskCard key={task.id} task={task} taskKey={doneKey(task)} />)}
          <WritingWorkbench week={week} day={day} sequenceKey={writingKey} />
        </>
      ) : null}

      {skill === "speaking" ? (
        <>
          <NativeText variant="title">Speaking 7+ · 12 haftalik reja</NativeText>
          <SpeakingWorkbench week={week} day={day} sequenceKey={speakingKey} />
        </>
      ) : null}
      <NativeText variant="caption" tone="muted" style={{ color: colors.mutedForeground }}>
        Rejadagi bloklarning tartibi va davomiyligi manba ilovadagi holicha saqlandi.
      </NativeText>
    </Screen>
  );
}
