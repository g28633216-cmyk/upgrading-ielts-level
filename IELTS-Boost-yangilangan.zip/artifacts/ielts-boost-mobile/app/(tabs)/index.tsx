import React, { useMemo } from "react";
import { Image, View } from "react-native";
import { useRouter } from "expo-router";
import {
  NativeBadge,
  NativeButton,
  NativeCard,
  NativeProgress,
  NativeText,
} from "@workspace/ielts-boost-design/native/primitives";
import { Screen } from "../../components/Screen";
import { TimerBanner } from "../../components/TimerBanner";
import { NEW_CARD_LIMIT, useAppStore } from "../../contexts/AppStore";
import { reviewCounts } from "../../data/flashcards";
import {
  dateKey,
  planIndex,
  readingPlan,
  speakingPlan,
  speakingWeekDay,
  weekDayFromIndex,
  writingPlan,
} from "../../data/plan";

const sections = [
  { id: "reading", title: "Reading", icon: "◫", color: "muted" as const },
  { id: "writing", title: "Writing", icon: "✎", color: "accent" as const },
  { id: "speaking", title: "Speaking", icon: "◉", color: "success" as const },
];

export default function HomeScreen() {
  const router = useRouter();
  const { state, update, loading, storageError, notice, dismissNotice } = useAppStore();
  const today = dateKey();
  const index = planIndex(state.planStart, today);
  const reading = weekDayFromIndex(index);
  const writing = weekDayFromIndex(Math.min(index, 83));
  const speaking = speakingWeekDay(state.planStart, today);
  const plans = useMemo(() => [
    { ...sections[0], slot: reading, tasks: readingPlan(reading.week, reading.day) },
    { ...sections[1], slot: writing, tasks: writingPlan(writing.week, writing.day) },
    { ...sections[2], slot: speaking, tasks: speakingPlan(speaking.week, speaking.day) },
  ], [reading.week, reading.day, writing.week, writing.day, speaking.week, speaking.day]);
  const totals = plans.map((section) => {
    const minutes = section.tasks.reduce((sum, task) => sum + task.minutes, 0);
    const completed = section.tasks.reduce(
      (sum, task) => sum + (state.done[`${section.id}:${section.slot.week}:${section.slot.day}:${task.id}`] ? task.minutes : 0),
      0,
    );
    return { ...section, minutes, completed };
  });
  const allMinutes = totals.reduce((sum, item) => sum + item.minutes, 0);
  const completedMinutes = totals.reduce((sum, item) => sum + item.completed, 0);
  const flashcardsDue = reviewCounts(state.cards, today, state.reviewLog[today]?.newCards ?? 0, NEW_CARD_LIMIT);

  return (
    <Screen>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 4 }}>
        <Image source={require("../../assets/images/icon.png")} style={{ width: 48, height: 48, borderRadius: 14 }} />
        <View style={{ flex: 1 }}>
          <NativeText variant="caption" tone="muted">{new Date().toLocaleDateString("uz-UZ", { weekday: "long", day: "numeric", month: "long" })}</NativeText>
          <NativeText variant="display" style={{ fontSize: 27, lineHeight: 34 }}>IELTS Boost</NativeText>
        </View>
        <NativeBadge tone="accent">12 hafta</NativeBadge>
      </View>

      {storageError ? (
        <NativeCard><NativeText tone="warning">{storageError}</NativeText></NativeCard>
      ) : null}
      {notice ? (
        <NativeCard style={{ gap: 8 }}>
          <NativeText tone="warning">{notice}</NativeText>
          <NativeButton variant="outline" onPress={dismissNotice}>Tushunarli</NativeButton>
        </NativeCard>
      ) : null}

      {!state.planStart ? (
        <NativeCard style={{ gap: 10 }}>
          <NativeBadge tone="accent">Tayyorlanish rejasi</NativeBadge>
          <NativeText variant="display" style={{ fontSize: 29, lineHeight: 37 }}>Bugundan boshlang.</NativeText>
          <NativeText tone="muted">Mavjud 12 haftalik Reading, Writing va Speaking tartibi saqlangan. Reja va kartalar offline ishlaydi.</NativeText>
          <NativeButton
            disabled={loading || Boolean(storageError)}
            onPress={() => update((current) => ({ ...current, planStart: dateKey() }))}
          >
            Rejani bugundan boshlash
          </NativeButton>
        </NativeCard>
      ) : (
        <>
          <NativeCard style={{ gap: 10 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <View style={{ flex: 1 }}>
                <NativeText variant="caption" tone="muted">Bugungi reja · kunlik jami</NativeText>
                <NativeText variant="display">{allMinutes} daqiqa</NativeText>
              </View>
              <NativeBadge tone={completedMinutes === allMinutes ? "success" : "accent"}>
                {completedMinutes}/{allMinutes} daq
              </NativeBadge>
            </View>
            <NativeProgress value={(completedMinutes / Math.max(1, allMinutes)) * 100} label="Bugungi jami reja" />
            <NativeText variant="caption" tone="muted">Reja boshlanishi: {state.planStart} · maqsad: Band 7+</NativeText>
          </NativeCard>
          <TimerBanner />
          {totals.map((section) => (
            <NativeCard key={section.id} style={{ gap: 9 }}>
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 9, flex: 1 }}>
                  <NativeBadge tone={section.color}>{section.icon}</NativeBadge>
                  <View>
                    <NativeText variant="title">{section.title}</NativeText>
                    <NativeText variant="caption" tone="muted">Hafta {section.slot.week} · {section.minutes} daqiqa</NativeText>
                  </View>
                </View>
                <NativeText variant="label">{section.completed}/{section.minutes}</NativeText>
              </View>
              <NativeProgress value={(section.completed / Math.max(1, section.minutes)) * 100} label={`${section.title} bajarilishi`} />
              <NativeButton
                variant="outline"
                onPress={() => router.push({ pathname: "/practice", params: { skill: section.id } })}
              >
                {section.title} rejasini ochish →
              </NativeButton>
            </NativeCard>
          ))}
        </>
      )}

      <View style={{ flexDirection: "row", gap: 10 }}>
        <NativeCard style={{ flex: 1, gap: 6 }}>
          <NativeText variant="caption" tone="muted">Kartalar</NativeText>
          <NativeText variant="title">{flashcardsDue} bugun</NativeText>
          <NativeButton variant="secondary" onPress={() => router.push("/review")}>Takrorlash</NativeButton>
        </NativeCard>
        <NativeCard style={{ flex: 1, gap: 6 }}>
          <NativeText variant="caption" tone="muted">Natija</NativeText>
          <NativeText variant="title">{Object.keys(state.done).length} blok</NativeText>
          <NativeButton variant="secondary" onPress={() => router.push("/progress")}>Kuzatish</NativeButton>
        </NativeCard>
      </View>
      <NativeText variant="caption" tone="muted">
        Listening bo‘limi qo‘shilmagan. YouTube’dagi Shadowing videolari internet bilan ochiladi.
      </NativeText>
    </Screen>
  );
}
