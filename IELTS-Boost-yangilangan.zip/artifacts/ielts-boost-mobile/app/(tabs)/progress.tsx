import React, { useMemo } from "react";
import { View } from "react-native";
import { NativeBadge, NativeCard, NativeProgress, NativeText } from "@workspace/ielts-boost-design/native/primitives";
import { Screen } from "../../components/Screen";
import { useAppStore } from "../../contexts/AppStore";
import { readingPlan, speakingPlan, writingPlan } from "../../data/plan";

export default function ProgressScreen() {
  const { state, savedAt } = useAppStore();
  const skills = useMemo(() => {
    const data = [
      { id: "reading", label: "Reading", plan: readingPlan },
      { id: "writing", label: "Writing", plan: writingPlan },
      { id: "speaking", label: "Speaking", plan: speakingPlan },
    ];
    return data.map((skill) => {
      let total = 0;
      let completed = 0;
      for (let week = 1; week <= 12; week += 1) {
        for (let day = 0; day < 7; day += 1) {
          skill.plan(week, day).forEach((task) => {
            total += task.minutes;
            if (state.done[`${skill.id}:${week}:${day}:${task.id}`]) completed += task.minutes;
          });
        }
      }
      return { ...skill, total, completed };
    });
  }, [state.done]);

  const completedDates = useMemo(() => {
    const unique = [...new Set(Object.values(state.doneAt))].sort().reverse();
    let streak = 0;
    const today = new Date();
    const key = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    if (!unique.includes(key(today))) today.setDate(today.getDate() - 1);
    while (unique.includes(key(today))) {
      streak += 1;
      today.setDate(today.getDate() - 1);
    }
    return { streak, days: unique.length };
  }, [state.doneAt]);

  const writingEntries = Object.values(state.writingScores);
  const bandValues = writingEntries.flatMap((entry) =>
    Object.values(entry).map((value) => Number(value)).filter((value) => Number.isFinite(value) && value >= 0 && value <= 9),
  );
  const writingAverage = bandValues.length ? bandValues.reduce((sum, value) => sum + value, 0) / bandValues.length : null;
  const reviewCount = Object.values(state.reviewLog).reduce((sum, log) => sum + log.reviewed, 0);
  const reviewCorrect = Object.values(state.reviewLog).reduce((sum, log) => sum + log.correct, 0);

  return (
    <Screen>
      <NativeText variant="display">Natijalar</NativeText>
      <NativeText tone="muted">Haqiqiy mashq va o‘zingiz kiritgan natijalar asosida. Kafolatlangan band va’da qilinmaydi.</NativeText>
      <View style={{ flexDirection: "row", gap: 10 }}>
        <NativeCard style={{ flex: 1, gap: 5 }}>
          <NativeText variant="caption" tone="muted">Ketma-ket kun</NativeText>
          <NativeText variant="display">{completedDates.streak}</NativeText>
        </NativeCard>
        <NativeCard style={{ flex: 1, gap: 5 }}>
          <NativeText variant="caption" tone="muted">Takrorlangan karta</NativeText>
          <NativeText variant="display">{reviewCount}</NativeText>
        </NativeCard>
      </View>
      {skills.map((skill) => (
        <NativeCard key={skill.id} style={{ gap: 9 }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <NativeText variant="title">{skill.label}</NativeText>
            <NativeBadge>{Math.round((skill.completed / Math.max(1, skill.total)) * 100)}%</NativeBadge>
          </View>
          <NativeProgress value={(skill.completed / Math.max(1, skill.total)) * 100} label={`${skill.label} bajarilishi`} />
          <NativeText variant="caption" tone="muted">{skill.completed} / {skill.total} reja daqiqasi belgilandi</NativeText>
        </NativeCard>
      ))}
      <NativeCard style={{ gap: 8 }}>
        <NativeText variant="title">Writing o‘z-o‘zini baholash</NativeText>
        <NativeText variant="display">{writingAverage == null ? "—" : writingAverage.toFixed(1)}</NativeText>
        <NativeText variant="caption" tone="muted">Kiritilgan {bandValues.length} mezon bo‘yicha o‘rtacha. Bu rasmiy IELTS natijasi emas.</NativeText>
      </NativeCard>
      <NativeCard style={{ gap: 8 }}>
        <NativeText variant="title">Karta sessiyalari</NativeText>
        <NativeText>To‘g‘ri: {reviewCorrect} / {reviewCount} ({reviewCount ? Math.round((reviewCorrect / reviewCount) * 100) : 0}%)</NativeText>
        <NativeText variant="caption" tone="muted">Mashq qilingan kunlar: {completedDates.days} · Kartalar: {state.cards.length}</NativeText>
      </NativeCard>
      <NativeText variant="caption" tone="muted">
        {savedAt ? `Oxirgi saqlash: ${new Date(savedAt).toLocaleTimeString()}` : "Ma’lumotlar avtomatik saqlanadi."}
      </NativeText>
    </Screen>
  );
}
