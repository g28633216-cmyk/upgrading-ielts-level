import React, { useEffect, useState } from "react";
import { Alert, Linking, Share, View } from "react-native";
import { NativeBadge, NativeButton, NativeCard, NativeInput, NativeText } from "@workspace/ielts-boost-design/native/primitives";
import { Screen } from "../../components/Screen";
import { useAppStore } from "../../contexts/AppStore";
import { READING_RESOURCES, SHADOWING_VIDEOS, SPEAKING_RESOURCES, WRITING_RESOURCES, dateFromKey, dateKey, dayDifference } from "../../data/plan";

export default function SettingsScreen() {
  const {
    state, update, storageError, saveFailed, savedAt, requestNotifications, resetData,
    setDailyReminder, clearDailyReminder, exportData, importData,
  } = useAppStore();
  const [restoreText, setRestoreText] = useState("");
  const [showRestore, setShowRestore] = useState(false);
  const [planDate, setPlanDate] = useState(state.planStart ?? dateKey());
  const [notificationStatus, setNotificationStatus] = useState(state.notificationsEnabled);

  useEffect(() => setPlanDate(state.planStart ?? dateKey()), [state.planStart]);
  const saveStartDate = () => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(planDate) || dateKey(dateFromKey(planDate)) !== planDate) {
      Alert.alert("Sana noto‘g‘ri", "Sanani YYYY-MM-DD ko‘rinishida kiriting.");
      return;
    }
    update((current) => ({ ...current, planStart: planDate }));
    Alert.alert("Sana saqlandi", "Kunlik reja shu sanadan hisoblanadi; bajarilgan bloklar o‘chmaydi.");
  };

  const enableNotifications = async () => {
    const enabled = await requestNotifications();
    setNotificationStatus(enabled);
    if (!enabled) {
      Alert.alert("Bildirishnomalar o‘chiq", "Telefon sozlamalaridan IELTS Boost bildirishnomalariga ruxsat bering.");
    }
  };

  const pickReminder = async (hour: number, minute: number) => {
    const ok = await setDailyReminder(hour, minute);
    if (!ok) Alert.alert("Eslatma yoqilmadi", "Telefon sozlamalaridan IELTS Boost bildirishnomalariga ruxsat bering.");
  };

  const backup = async () => {
    try {
      await Share.share({ message: exportData(), title: "IELTS Boost zaxira nusxasi" });
    } catch {
      Alert.alert("Zaxira yaratilmadi", "Qayta urinib ko‘ring.");
    }
  };

  const restore = () => {
    Alert.alert(
      "Zaxiradan tiklash",
      "Joriy reja natijalari, yozuvlar va kartalar zaxiradagi nusxa bilan almashtiriladi. Davom etasizmi?",
      [
        { text: "Bekor qilish", style: "cancel" },
        {
          text: "Tiklash",
          style: "destructive",
          onPress: () => {
            const result = importData(restoreText.trim());
            Alert.alert(result.ok ? "Tiklandi" : "Tiklanmadi", result.message);
            if (result.ok) {
              setRestoreText("");
              setShowRestore(false);
            }
          },
        },
      ],
    );
  };

  const confirmReset = () => {
    Alert.alert(
      "Barcha ma’lumotni o‘chirasizmi?",
      "Bu telefoningizdagi reja, yozuvlar, natijalar va kartalarni butunlay o‘chiradi. Bu amalni qaytarib bo‘lmaydi.",
      [
        { text: "Bekor qilish", style: "cancel" },
        { text: "Hammasini o‘chirish", style: "destructive", onPress: () => void resetData() },
      ],
    );
  };

  const allResources = [...READING_RESOURCES, ...WRITING_RESOURCES, ...SPEAKING_RESOURCES];
  return (
    <Screen>
      <NativeText variant="display">Sozlamalar</NativeText>
      <NativeText tone="muted">Reja sanasi, telefon bildirishnomalari, maxfiylik va ishonchli manbalar.</NativeText>

      <NativeCard style={{ gap: 9 }}>
        <NativeText variant="title">Reja boshlanish sanasi</NativeText>
        <NativeText variant="caption" tone="muted">Sana o‘zgarsa, 12 haftalik tartib o‘zgarmaydi. Bajarilgan bloklar saqlanib qoladi.</NativeText>
        <NativeInput value={planDate} onChangeText={setPlanDate} placeholder="YYYY-MM-DD" accessibilityLabel="Reja boshlanish sanasi" />
        <NativeButton onPress={saveStartDate}>Sanani saqlash</NativeButton>
        {state.planStart ? <NativeText variant="caption" tone="muted">Reja boshlanganiga {Math.max(0, dayDifference(state.planStart, dateKey()))} kun bo‘ldi.</NativeText> : null}
      </NativeCard>

      <NativeCard style={{ gap: 9 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
          <NativeText variant="title">Fon rejimidagi taymer</NativeText>
          <NativeBadge tone={notificationStatus ? "success" : "warning"}>{notificationStatus ? "Yoqilgan" : "Ruxsat so‘ralmagan"}</NativeBadge>
        </View>
        <NativeText tone="muted">Taymer tugaganda telefon bildirishnoma va standart ovoz yuboradi. Bu iOS/Android ruxsati hamda qurilmaning ovoz va batareya sozlamalariga bog‘liq.</NativeText>
        <NativeButton onPress={() => void enableNotifications()}>{notificationStatus ? "Ruxsatni qayta tekshirish" : "Bildirishnomani yoqish"}</NativeButton>
        {!notificationStatus ? (
          <NativeButton variant="outline" onPress={() => void Linking.openSettings()}>Telefon sozlamalarini ochish</NativeButton>
        ) : null}
      </NativeCard>

      <NativeCard style={{ gap: 9 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
          <NativeText variant="title">Kunlik eslatma</NativeText>
          <NativeBadge tone={state.dailyReminder ? "success" : "muted"}>
            {state.dailyReminder ? `${String(state.dailyReminder.hour).padStart(2, "0")}:${String(state.dailyReminder.minute).padStart(2, "0")}` : "O‘chiq"}
          </NativeBadge>
        </View>
        <NativeText tone="muted">Har kuni shu vaqtda bugungi rejani eslatib turadi. Internet kerak emas.</NativeText>
        <View style={{ flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
          {([[7, 0], [13, 0], [18, 0], [21, 0]] as const).map(([hour, minute]) => (
            <NativeButton
              key={hour}
              variant={state.dailyReminder?.hour === hour && state.dailyReminder?.minute === minute ? "primary" : "outline"}
              onPress={() => void pickReminder(hour, minute)}
              style={{ flex: 1, paddingHorizontal: 6 }}
            >
              {`${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`}
            </NativeButton>
          ))}
        </View>
        {state.dailyReminder ? <NativeButton variant="outline" onPress={() => void clearDailyReminder()}>Eslatmani o‘chirish</NativeButton> : null}
      </NativeCard>

      <NativeCard style={{ gap: 9 }}>
        <NativeText variant="title">Zaxira nusxa</NativeText>
        <NativeText tone="muted">Reja natijalari, yozuvlar, ballar va kartalar jadvalini matn sifatida saqlab qo‘ying (Telegram “Saved Messages” yoki Notes’ga). Telefon almashganda yoki ilova qayta o‘rnatilganda shu matndan tiklaysiz. Ovoz yozuvlari zaxiraga kirmaydi.</NativeText>
        <NativeButton onPress={() => void backup()}>Zaxira nusxa yaratish</NativeButton>
        <NativeButton variant="outline" onPress={() => setShowRestore((value) => !value)}>
          {showRestore ? "Tiklashni yopish" : "Zaxiradan tiklash"}
        </NativeButton>
        {showRestore ? (
          <View style={{ gap: 8 }}>
            <NativeInput
              multiline
              value={restoreText}
              onChangeText={setRestoreText}
              placeholder="Zaxira matnini shu yerga qo‘ying"
              accessibilityLabel="Zaxira nusxa matni"
              autoCapitalize="none"
              autoCorrect={false}
            />
            <NativeButton variant="danger" onPress={restore} disabled={!restoreText.trim()}>Tiklash</NativeButton>
          </View>
        ) : null}
      </NativeCard>

      <NativeCard style={{ gap: 9 }}>
        <NativeText variant="title">Maxfiylik va saqlash</NativeText>
        <NativeBadge tone={storageError || saveFailed ? "warning" : "success"}>
          {storageError ? "Saqlash o‘chiq" : saveFailed ? "Saqlashda xato, qayta uriniladi" : "Qurilmada shifrlangan"}
        </NativeBadge>
        <NativeText tone="muted">
          Reja, kartalar va yozuvlar AES-GCM bilan shifrlanadi. Kalit iOS Keychain yoki Android Keystore’da; ilova hisob ochmaydi va serverga sinxronlamaydi.
        </NativeText>
        <NativeText variant="caption" tone="muted">
          Ilovani o‘chirib tashlash yoki telefonni almashtirishdan oldin yuqoridagi “Zaxira nusxa” orqali nusxa oling. Aks holda ma’lumot qaytmasligi mumkin.
        </NativeText>
        {savedAt ? <NativeText variant="caption" tone="muted">Avtomatik saqlangan: {new Date(savedAt).toLocaleString()}</NativeText> : null}
      </NativeCard>

      <NativeCard style={{ gap: 9 }}>
        <NativeText variant="title">Offline ishlash</NativeText>
        <NativeText tone="muted">Reja, tarjimalar, Speaking savollari, kartalar va yozuv daftari internetsiz ochiladi. YouTube videolari internet talab qiladi va alohida ilova yoki brauzerda ochiladi.</NativeText>
      </NativeCard>

      <NativeCard style={{ gap: 9 }}>
        <NativeText variant="title">Foydalanilgan manbalar</NativeText>
        {allResources.map((resource) => (
          <View key={`${resource.source}-${resource.title}`} style={{ gap: 4 }}>
            <NativeText variant="label">{resource.source} · {resource.title}</NativeText>
            <NativeButton variant="outline" onPress={() => void Linking.openURL(resource.url)}>Rasmiy manbani ochish ↗</NativeButton>
          </View>
        ))}
        {SHADOWING_VIDEOS.map((video) => (
          <View key={video.url} style={{ gap: 4 }}>
            <NativeText variant="caption" tone="muted">{video.source} · {video.title}</NativeText>
            <NativeButton variant="outline" onPress={() => void Linking.openURL(video.url)}>YouTube videosini ochish ↗</NativeButton>
          </View>
        ))}
      </NativeCard>

      <NativeButton variant="danger" onPress={confirmReset}>Barcha mahalliy ma’lumotni o‘chirish</NativeButton>
    </Screen>
  );
}
