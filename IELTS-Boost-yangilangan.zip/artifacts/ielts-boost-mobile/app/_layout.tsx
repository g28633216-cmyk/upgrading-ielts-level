import React, { useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import * as SplashScreen from 'expo-splash-screen';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { useFonts } from '@workspace/ielts-boost-design/hooks/use-fonts';
import { AppStoreProvider, useAppStore } from '@/contexts/AppStore';
import { Stack } from 'expo-router';

SplashScreen.preventAutoHideAsync().catch(() => undefined);

const queryClient = new QueryClient();

// Shrift va saqlangan ma'lumot tayyor bo'lguncha splash ko'rinadi: "Rejani boshlash" kartasi yolg'on chaqnamaydi.
function RootLayoutNav({ fontsReady }: { fontsReady: boolean }) {
  const { loading } = useAppStore();
  const ready = fontsReady && !loading;

  useEffect(() => {
    if (ready) SplashScreen.hideAsync().catch(() => undefined);
  }, [ready]);

  if (!ready) return null;
  return (
    <Stack screenOptions={{ headerBackTitle: 'Orqaga' }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
    </Stack>
  );
}

export default function RootLayout() {
  const { loaded } = useFonts();

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <AppStoreProvider>
                <RootLayoutNav fontsReady={loaded} />
              </AppStoreProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
